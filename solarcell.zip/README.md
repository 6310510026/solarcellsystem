# solarcell

plant owner-->
username : test2
email : 
password : iamuser2


data analyst -->
username: test4
email: 
password: iamuser4

drone controller -->
username: sureeyanee
email:
password: thisissunny123

super user (admin) --> (login ด้วย admin site)
username: admin
password: 123
